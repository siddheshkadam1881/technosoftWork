Authorization Server
==================

This is the authorization server example.

# Installation
```
git clone https://github.com/FrankHassanabad/Oauth2orizeRecipes.git
cd Oauth2orizeRecipes/authorization-server
npm install
npm start
```

Go here for how to use the REST API
https://github.com/FrankHassanabad/Oauth2orizeRecipes/wiki/OAuth2orize-Authorization-Server-Tests

Go here for high level views of security scenarios
https://github.com/FrankHassanabad/Oauth2orizeRecipes/wiki/Security-Scenarios
